<?php 

$MESS ['DRDROID_KEYRIGHTS_NAME'] = 'KeyRights';

$MESS ['DRDROID_KEYRIGHTS_DESCRIPTION'] = 'KeyRights';

$MESS ['DRDROID_KEYRIGHTS'] = 'KeyRights';
$MESS ['KEYRIGHTS_SCRUMBAN_NAME'] = 'KeyRights';
$MESS ['KEYRIGHTS_SCRUMBAN_DESCRIPTION'] = 'Безопасное хранение паролей с разграничением прав доступа';
